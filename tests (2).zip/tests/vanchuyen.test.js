/**
 * @jest-environment jsdom
 */
const { themVanChuyen } = require("../app");

document.body.innerHTML = `
<table id="bang_vanchuyen">
<tr><th>Mã VC</th><th>Mã đơn hàng</th><th>Shipper</th><th>Ngày</th><th>Trạng thái</th></tr>
</table>

<input id="vc_ma">
<input id="vc_donhang">
<input id="vc_shipper">
<input id="vc_ngay">
<input id="vc_trangthai">
`;

test("Thêm thông tin vận chuyển", () => {
    vc_ma.value = "VC01";
    vc_donhang.value = "DH01";
    vc_shipper.value = "SP01";
    vc_ngay.value = "2025-03-01";
    vc_trangthai.value = "Đang giao";

    themVanChuyen();

    const row = document.getElementById("bang_vanchuyen").rows[1];

    expect(row.cells[2].textContent).toBe("SP01");
});
