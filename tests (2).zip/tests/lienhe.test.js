/**
 * @jest-environment jsdom
 */
const { themLienHe } = require("../app");

document.body.innerHTML = `
<table id="bang_lienhe">
<tr><th>Mã liên hệ</th><th>Mã khách</th><th>Mã dịch vụ</th><th>Ngày</th><th>Nội dung</th><th>Trạng thái</th></tr>
</table>

<input id="lh_ma">
<input id="lh_khachhang">
<input id="lh_dichvu">
<input id="lh_ngay">
<input id="lh_noidung">
<input id="lh_trangthai">
`;

test("Thêm liên hệ", () => {
    lh_ma.value = "LH01";
    lh_khachhang.value = "KH02";
    lh_dichvu.value = "DV01";
    lh_ngay.value = "2025-02-10";
    lh_noidung.value = "Tư vấn đổi size";
    lh_trangthai.value = "Đã xử lý";

    themLienHe();

    const row = document.getElementById("bang_lienhe").rows[1];

    expect(row.cells[4].textContent).toBe("Tư vấn đổi size");
});
