/**
 * @jest-environment jsdom
 */

const { themDonHang } = require("../app");

document.body.innerHTML = `
<table id="bang_donhang">
<tr><th>Mã đơn</th><th>Mã khách</th><th>Ngày</th><th>Địa chỉ</th><th>Tổng tiền</th><th>Trạng thái</th></tr>
</table>

<input id="dh_ma">
<input id="dh_khachhang">
<input id="dh_ngay">
<input id="dh_diachi">
<input id="dh_tongtien">
<input id="dh_trangthai">
`;

test("Thêm đơn hàng thành công", () => {
    dh_ma.value = "DH01";
    dh_khachhang.value = "KH01";
    dh_ngay.value = "2025-01-01";
    dh_diachi.value = "Hà Nội";
    dh_tongtien.value = "500000";
    dh_trangthai.value = "Chờ duyệt";

    themDonHang();

    const row = document.getElementById("bang_donhang").rows[1];

    expect(row.cells[0].textContent).toBe("DH01");
    expect(row.cells[5].textContent).toBe("Chờ duyệt");
});
