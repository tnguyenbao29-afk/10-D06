/**
 * @jest-environment jsdom
 */
const { themDichVu } = require("../app");

document.body.innerHTML = `
<table id="bang_dichvu">
<tr><th>Mã</th><th>Họ tên</th><th>SĐT</th></tr>
</table>

<input id="dv_ma">
<input id="dv_ten">
<input id="dv_sdt">
`;

test("Thêm nhân viên dịch vụ", () => {
    dv_ma.value = "DV01";
    dv_ten.value = "Trần B";
    dv_sdt.value = "0909999999";

    themDichVu();

    const row = document.getElementById("bang_dichvu").rows[1];

    expect(row.cells[1].textContent).toBe("Trần B");
});
