/**
 * @jest-environment jsdom
 */

const { themKhachHang } = require("../app");

document.body.innerHTML = `
<table id="bang_khachhang">
    <tr><th>Họ tên</th><th>Điện thoại</th><th>Địa chỉ</th><th>Email</th></tr>
</table>

<input id="kh_ten">
<input id="kh_sdt">
<input id="kh_diachi">
<input id="kh_email">
`;

test("Thêm khách hàng vào bảng", () => {
    // gán dữ liệu
    document.getElementById("kh_ten").value = "Nguyễn Văn A";
    document.getElementById("kh_sdt").value = "0901234567";
    document.getElementById("kh_diachi").value = "TPHCM";
    document.getElementById("kh_email").value = "a@gmail.com";

    themKhachHang();

    const table = document.getElementById("bang_khachhang").rows;

    expect(table.length).toBe(2);        // có thêm 1 dòng
    expect(table[1].cells[0].textContent).toBe("Nguyễn Văn A");
    expect(table[1].cells[1].textContent).toBe("0901234567");
});
