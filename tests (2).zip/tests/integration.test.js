/**
 * @jest-environment jsdom
 */
const {
    themKhachHang,
    themDonHang,
    themLienHe,
    themVanChuyen,
    themDichVu
} = require("../app");

document.body.innerHTML = `
<!-- KH -->
<input id="kh_ten">
<input id="kh_sdt">
<input id="kh_diachi">
<input id="kh_email">
<table id="bang_khachhang"><tr></tr></table>

<!-- ĐH -->
<input id="dh_ma">
<input id="dh_khachhang">
<input id="dh_ngay">
<input id="dh_diachi">
<input id="dh_tongtien">
<input id="dh_trangthai">
<table id="bang_donhang"><tr></tr></table>

<!-- LH -->
<input id="lh_ma">
<input id="lh_khachhang">
<input id="lh_dichvu">
<input id="lh_ngay">
<input id="lh_noidung">
<input id="lh_trangthai">
<table id="bang_lienhe"><tr></tr></table>

<!-- VC -->
<input id="vc_ma">
<input id="vc_donhang">
<input id="vc_shipper">
<input id="vc_ngay">
<input id="vc_trangthai">
<table id="bang_vanchuyen"><tr></tr></table>

<!-- DV -->
<input id="dv_ma">
<input id="dv_ten">
<input id="dv_sdt">
<table id="bang_dichvu"><tr></tr></table>
`;

test("Tích hợp toàn hệ thống", () => {

    // 1) KHÁCH HÀNG
    kh_ten.value = "A";
    kh_sdt.value = "111";
    kh_diachi.value = "HN";
    kh_email.value = "a@mail.com";
    themKhachHang();

    // 2) ĐƠN HÀNG thuộc về KH A
    dh_ma.value = "DH01";
    dh_khachhang.value = "A";
    dh_ngay.value = "2025-01-01";
    dh_diachi.value = "HN";
    dh_tongtien.value = "500000";
    dh_trangthai.value = "Đang giao";
    themDonHang();

    // 3) DỊCH VỤ KH
    dv_ma.value = "DV01";
    dv_ten.value = "Nhân viên X";
    dv_sdt.value = "0900000000";
    themDichVu();

    // 4) LIÊN HỆ liên quan KH A
    lh_ma.value = "LH01";
    lh_khachhang.value = "A";
    lh_dichvu.value = "DV01";
    lh_ngay.value = "2025-01-03";
    lh_noidung.value = "Hỗ trợ đổi size";
    lh_trangthai.value = "Đang xử lý";
    themLienHe();

    // 5) VẬN CHUYỂN đơn DH01
    vc_ma.value = "VC01";
    vc_donhang.value = "DH01";
    vc_shipper.value = "SP01";
    vc_ngay.value = "2025-01-02";
    vc_trangthai.value = "Đang giao";
    themVanChuyen();

    // KIỂM TRA LIÊN KẾT
    const dh = document.getElementById("bang_donhang").rows[1];
    const lh = document.getElementById("bang_lienhe").rows[1];
    const vc = document.getElementById("bang_vanchuyen").rows[1];

    expect(dh.cells[1].textContent).toBe("A");
    expect(lh.cells[1].textContent).toBe("A");
    expect(vc.cells[1].textContent).toBe("DH01");
});
