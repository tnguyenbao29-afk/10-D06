<?php
include "config.php";
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "staff") {
    header("Location: login.php"); exit();
}

// Thống kê
$total_customers = $conn->query("SELECT COUNT(*) FROM CUSTOMER")->fetch_row()[0];
$today = date('Y-m-d');
$orders_today = $conn->query("SELECT COUNT(*) FROM ORDERS WHERE OrderDate='$today'")->fetch_row()[0];
$first_day = date('Y-m-01');
$revenue_month = $conn->query("SELECT COALESCE(SUM(TotalAmount),0) FROM ORDERS WHERE OrderDate >= '$first_day'")->fetch_row()[0];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>GIÀY DEP - Quản Trị</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --primary: #4f46e5; --primary-light: #6366f1; --sidebar: #1e1b4b; --bg: #f8fafc; --card: #ffffff;
        --text: #1e293b; --text-light: #64748b; --success: #10b981; --warning: #f59e0b; --border: #e2e8f0;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: var(--bg); color: var(--text); display: flex; height: 100vh; overflow: hidden; }

    /* Sidebar */
    .sidebar { width: 270px; background: linear-gradient(135deg, var(--sidebar), #312e81); color: white; padding: 30px 0; box-shadow: 6px 0 20px rgba(0,0,0,0.15); }
    .logo { text-align: center; padding: 0 20px 40px; border-bottom: 1px solid rgba(255,255,255,0.1); }
    .logo i { font-size: 48px; color: #c4b5fd; }
    .logo h2 { margin-top: 12px; font-size: 22px; font-weight: 700; }

    .menu-item { padding: 16px 28px; cursor: pointer; display: flex; align-items: center; gap: 16px; font-weight: 500; transition: all 0.3s; }
    .menu-item:hover { background: rgba(255,255,255,0.12); padding-left: 35px; }
    .menu-item.active { background: var(--primary-light); position: relative; }
    .menu-item.active::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 5px; background: white; }

    /* Main Content */
    .main-content { flex: 1; padding: 30px; overflow-y: auto; background: linear-gradient(to bottom right, #f0f9ff, #e0f2fe); }
    .content { display: none; }
    .content.active { display: block; }
    .header-title { font-size: 28px; font-weight: 700; color: var(--primary); margin-bottom: 8px; display: flex; align-items: center; gap: 12px; }
    .subtitle { color: var(--text-light); font-size: 15px; margin-bottom: 30px; }

    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; margin-bottom: 40px; }
    .stat-card { background: var(--card); border-radius: 20px; padding: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); transition: 0.3s; }
    .stat-card:hover { transform: translateY(-8px); }
    .stat-card .icon { width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 28px; color: white; margin-bottom: 16px; }
    .stat-card h3 { font-size: 14px; color: var(--text-light); margin-bottom: 8px; }
    .stat-card .value { font-size: 32px; font-weight: 700; color: var(--text); }

    /* Chat Frame */
    .chat-frame { width: 100%; height: calc(100vh - 200px); border: none; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.12); background: white; }

    /* Table */
    .card { background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.08); margin-bottom: 30px; }
    .card-header { background: var(--primary); color: white; padding: 18px 28px; font-size: 18px; font-weight: 600; }
    .card-body { padding: 28px; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f8fafc; padding: 16px 14px; text-align: left; font-weight: 600; color: var(--text); border-bottom: 2px solid var(--primary); }
    td { padding: 16px 14px; border-bottom: 1px solid var(--border); }
    tr:hover td { background: #f8faff; }
    .status { padding: 8px 16px; border-radius: 50px; font-size: 13px; font-weight: 600; text-transform: uppercase; }
    .status.pending { background: #fef3c7; color: #d97706; }
    .status.success { background: #d1fae5; color: #059669; }
    .btn-add { display: inline-block; padding: 12px 24px; background: var(--primary); color: white; border-radius: 12px; text-decoration: none; font-weight: 600; margin-bottom: 20px; }
    .btn-add:hover { background: #4338ca; }
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="logo">
        <i class="fas fa-shoe-prints"></i>
        <h2>GIÀY DEP</h2>
    </div>
    <div class="menu-item active" onclick="show('trangchu', this)">
        <i class="fas fa-home"></i><span>Trang Chủ</span>
    </div>
    <div class="menu-item" onclick="show('chat', this)">
        <i class="fas fa-headset"></i><span>Chat Hỗ Trợ</span>
    </div>
    <div class="menu-item" onclick="show('donhang', this)">
        <i class="fas fa-shopping-cart"></i><span>Đơn Hàng</span>
    </div>
    <!-- Thêm nút Đăng Xuất -->
    <div class="menu-item" style="margin-top: auto;">
        <a href="logout.php" style="color:white; text-decoration:none; display:flex; align-items:center; gap:16px; width:100%;">
            <i class="fas fa-right-from-bracket"></i><span>Đăng Xuất</span>
        </a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">

    <!-- Trang Chủ -->
    <div id="trangchu" class="content active">
        <div class="header-title">Trang Chủ</div>
        <p class="subtitle">Chào mừng <strong><?php echo htmlspecialchars($_SESSION["name"] ?? "Nhân viên"); ?></strong></p>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="icon" style="background:#4f46e5;"><i class="fas fa-users"></i></div>
                <h3>Tổng Khách Hàng</h3>
                <div class="value"><?php echo number_format($total_customers); ?></div>
            </div>
            <div class="stat-card">
                <div class="icon" style="background:#10b981;"><i class="fas fa-shopping-bag"></i></div>
                <h3>Đơn Hàng Hôm Nay</h3>
                <div class="value"><?php echo $orders_today; ?></div>
            </div>
            <div class="stat-card">
                <div class="icon" style="background:#f59e0b;"><i class="fas fa-coins"></i></div>
                <h3>Doanh Thu Tháng</h3>
                <div class="value"><?php echo number_format($revenue_month); ?> đ</div>
            </div>
        </div>
    </div>

    <!-- Chat Hỗ Trợ -->
    <div id="chat" class="content">
        <div class="header-title">Chat Hỗ Trợ Khách Hàng</div>
        <p class="subtitle">Hỗ trợ trực tuyến realtime</p>
        <!-- DÙNG IFRAME → KHÔNG BỊ VỠ LAYOUT -->
        <iframe src="chat_staff.php" class="chat-frame"></iframe>
    </div>

    <!-- Đơn Hàng -->
    <div id="donhang" class="content">
        <div class="header-title">Quản Lý Đơn Hàng</div>
        <p class="subtitle">Theo dõi và xử lý đơn hàng</p>
        <a href="add_order.php" class="btn-add">+ Thêm Đơn Hàng</a>

        <div class="card">
            <div class="card-header">Danh sách đơn hàng gần đây</div>
            <div class="card-body">
                <table>
                    <thead>
                        <tr>
                            <th>Mã đơn</th><th>Khách hàng</th><th>Ngày đặt</th><th>Tổng tiền</th><th>Trạng thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $res = $conn->query("SELECT o.OrderID, c.FullName, o.OrderDate, o.TotalAmount, o.OrderStatus
                                             FROM ORDERS o JOIN CUSTOMER c ON o.CustomerID = c.CustomerID
                                             ORDER BY o.OrderDate DESC LIMIT 20");
                        if ($res->num_rows == 0) {
                            echo "<tr><td colspan='5' style='text-align:center;padding:60px;color:#94a3b8'>
                                    <i class='fas fa-inbox' style='font-size:48px'></i><br>Chưa có đơn hàng
                                  </td></tr>";
                        } else {
                            while ($r = $res->fetch_assoc()) {
                                $status_class = ($r['OrderStatus'] == 'Đang xử lý' || $r['OrderStatus'] == 'Chờ xác nhận') ? 'pending' : 'success';
                                echo "<tr>
                                    <td><strong>#DH{$r['OrderID']}</strong></td>
                                    <td>{$r['FullName']}</td>
                                    <td>" . date("d/m/Y", strtotime($r['OrderDate'])) . "</td>
                                    <td>" . number_format($r['TotalAmount']) . " đ</td>
                                    <td><span class='status $status_class'>{$r['OrderStatus']}</span></td>
                                </tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script>
function show(id, el) {
    document.querySelectorAll('.content').forEach(c => c.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
    el.classList.add('active');
}
</script>
</body>
</html>