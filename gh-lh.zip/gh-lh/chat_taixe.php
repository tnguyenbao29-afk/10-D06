<?php
session_start();
include "config.php";

// Chỉ cho tài xế vào
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='driver'){
    header("Location: login.php");
    exit();
}

$driver_id = $_SESSION['user_id'];

// Lấy danh sách khách hàng có đơn được giao hoặc đang chờ
$customers = $conn->query("
    SELECT DISTINCT c.CustomerID, c.FullName
    FROM CUSTOMER c
    JOIN ORDERS o ON c.CustomerID = o.CustomerID
    JOIN DELIVERY d ON o.OrderID = d.OrderID
    WHERE d.DriverID = $driver_id OR d.DriverID IS NULL
    ORDER BY c.FullName ASC
");

// Xử lý gửi tin nhắn
if(isset($_POST['send_message'])){
    $receiver_id = intval($_POST['receiver_id']);
    $message = $conn->real_escape_string($_POST['message']);
    if(!empty($message)){
        $conn->query("INSERT INTO MESSAGES_DRIVER (SENDER_ID, RECEIVER_ID, MESSAGE) 
                      VALUES ($driver_id, $receiver_id, '$message')");
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chat Tài Xế</title>
<style>
body{font-family:sans-serif;background:#f0f2f5;padding:10px;}
.chat-container{display:flex; gap:20px;}
.customer-list{width:200px; background:#fff;padding:10px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
.customer-list div{padding:8px;cursor:pointer;border-radius:6px;margin-bottom:5px;}
.customer-list div.active, .customer-list div:hover{background:#4f46e5;color:white;}
.chat-box{flex:1; background:#fff;padding:10px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
.messages{height:300px;overflow-y:auto;border:1px solid #ccc;padding:10px;margin-bottom:10px;border-radius:6px;}
.message{margin-bottom:8px;}
.message.driver{color:#fff;background:#4f46e5;padding:6px 10px;border-radius:6px;display:inline-block;}
.message.customer{color:#000;background:#e2e8f0;padding:6px 10px;border-radius:6px;display:inline-block;}
form{display:flex; gap:6px;}
form input{flex:1;padding:8px;border-radius:6px;border:1px solid #ccc;}
form button{padding:8px 12px;background:#4f46e5;color:white;border:none;border-radius:6px;cursor:pointer;}
</style>
<script>
function selectCustomer(id,name){
    document.getElementById('receiver_id').value = id;
    document.getElementById('chat-header').innerText = "Chat với "+name;

    // Highlight selected
    document.querySelectorAll('.customer-list div').forEach(d=>d.classList.remove('active'));
    document.getElementById('customer_'+id).classList.add('active');

    // Reload messages
    document.getElementById('chat-messages').innerHTML = "";
    fetchMessages();
}

function fetchMessages(){
    let receiver_id = document.getElementById('receiver_id').value;
    if(receiver_id=="") return;
    fetch('fetch_messages_taixe.php?receiver_id='+receiver_id)
        .then(res=>res.text())
        .then(data=>{
            document.getElementById('chat-messages').innerHTML = data;
            document.getElementById('chat-messages').scrollTop = document.getElementById('chat-messages').scrollHeight;
        });
}

// Reload messages mỗi 2 giây
setInterval(fetchMessages,2000);
</script>
</head>
<body>

<div class="chat-container">
    <div class="customer-list">
        <h3>Khách hàng</h3>
        <?php while($c=$customers->fetch_assoc()): ?>
            <div id="customer_<?php echo $c['CustomerID']; ?>" onclick="selectCustomer('<?php echo $c['CustomerID']; ?>','<?php echo $c['FullName']; ?>')">
                <?php echo htmlspecialchars($c['FullName']); ?>
            </div>
        <?php endwhile; ?>
    </div>

    <div class="chat-box">
        <h3 id="chat-header">Chọn khách để chat</h3>
        <div class="messages" id="chat-messages"></div>
        <form method="post" onsubmit="return !!document.getElementById('receiver_id').value;">
            <input type="hidden" name="receiver_id" id="receiver_id">
            <input type="text" name="message" placeholder="Nhập tin nhắn...">
            <button type="submit" name="send_message">Gửi</button>
        </form>
    </div>
</div>

</body>
</html>
