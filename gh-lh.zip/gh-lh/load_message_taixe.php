<?php
session_start();
include "config.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'driver') exit;

$driver_id = $_SESSION['user_id'];
$customer_id = intval($_GET['customer_id']);

$res = $conn->query("
    SELECT * FROM MESSAGES_DRIVER 
    WHERE (SENDER_ID=$driver_id AND RECEIVER_ID=$customer_id)
       OR (SENDER_ID=$customer_id AND RECEIVER_ID=$driver_id)
    ORDER BY SENT_AT ASC
");

while($r=$res->fetch_assoc()){
    $cls = ($r['SENDER_ID']==$driver_id) ? 'driver' : 'customer';
    echo "<div class='message $cls'>".htmlspecialchars($r['MESSAGE'])."</div>";
}
