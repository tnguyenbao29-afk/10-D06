<?php
include "config.php";
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "staff") {
    header("Location: login.php"); exit();
}
$staff_id = $_SESSION["user_id"];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Nhân Viên Hỗ Trợ</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
    :root{--pri:#4361ee;--bg:#f0f2f5;--success:#06d6a0}
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:'Segoe UI',sans-serif;background:var(--bg);height:100vh;display:flex;flex-direction:column;color:#333}
    .header{background:white;padding:15px 20px;box-shadow:0 2px 10px rgba(0,0,0,.1);display:flex;align-items:center;gap:15px}
    .avatar{width:50px;height:50px;background:var(--pri);color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:22px}
    .status{width:12px;height:12px;background:var(--success);border-radius:50%;position:relative;top:-8px;left:35px;border:3px solid white}
    .chat-body{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:12px}
    .msg-customer{background:var(--pri);color:white;align-self:flex-end;border-radius:18px;border-bottom-right-radius:4px;padding:11px 16px;max-width:75%;word-wrap:break-word}
    .msg-staff{background:white;border:1px solid #e0e0e0;align-self:flex-start;border-radius:18px;border-bottom-left-radius:4px;padding:11px 16px;max-width:75%;word-wrap:break-word}
    .time{font-size:11px;margin-top:5px;opacity:0.8;text-align:right;color:#eee}
    .msg-staff .time{color:#999}
    .input-area{background:white;padding:15px 20px;box-shadow:0 -2px 10px rgba(0,0,0,.05);display:flex;gap:12px;align-items:center}
    input[type=text]{flex:1;padding:14px 18px;border-radius:30px;border:1px solid #ddd;outline:none;font-size:15px}
    button{background:var(--pri);color:white;border:none;width:50px;height:50px;border-radius:50%;cursor:pointer;font-size:20px}
    button:hover{background:#3f37c9}
    .welcome{text-align:center;color:#777;margin-top:60px;font-size:16px}
</style>
</head>
<body>

<div class="header">
    <div class="avatar" id="custAvatar">K</div>
    <div>
        <h3 id="custName">Đang tải khách...</h3>
        <small>Khách hàng</small>
    </div>
    <div class="status"></div>
</div>

<div class="chat-body" id="messages">
    <div class="welcome">Đang kết nối với khách hàng...</div>
</div>

<div class="input-area">
    <input type="text" id="msg" placeholder="Nhập tin nhắn..." autocomplete="off"
           onkeypress="if(event.key==='Enter') sendMessage()">
    <button onclick="sendMessage()">Send</button>
</div>

<script>
let currentCustomer = 0;

// Lấy khách duy nhất
function getCustomer() {
    fetch("auto_select_customer.php")
    .then(r => r.json())
    .then(d => {
        if (d.id && d.id != currentCustomer) {
            currentCustomer = d.id;
            document.getElementById("custName").textContent = d.name;
            document.getElementById("custAvatar").textContent = d.name.charAt(0).toUpperCase();
            loadMessages();
        }
    });
}

// Load tin nhắn
function loadMessages() {
    if (!currentCustomer) return;
    fetch("load_message.php?customer_id=" + currentCustomer + "&t=" + Date.now())
    .then(r => r.text())
    .then(html => {
        const box = document.getElementById("messages");
        const atBottom = box.scrollHeight - box.clientHeight - box.scrollTop < 100;
        box.innerHTML = html || "<div class='welcome'>Chưa có tin nhắn nào</div>";
        if (atBottom) box.scrollTop = box.scrollHeight;
    });
}

// Gửi tin
function sendMessage() {
    if (!currentCustomer) return alert("Chưa có khách!");
    const msg = document.getElementById("msg").value.trim();
    if (!msg) return;

    fetch("send_message.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: `sender_id=<?= $staff_id ?>&receiver_id=${currentCustomer}&role=staff&message=${encodeURIComponent(msg)}`
    }).then(() => {
        document.getElementById("msg").value = "";
        loadMessages();
    });
}

// Tự động chạy
setInterval(getCustomer, 2000);
setInterval(() => { if(currentCustomer) loadMessages(); }, 1200);
getCustomer();
</script>

</body>
</html>