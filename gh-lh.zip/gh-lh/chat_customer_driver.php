<?php
session_start();
include "config.php";

// Chỉ khách hàng
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='customer'){
    exit("Chỉ khách hàng mới truy cập được.");
}
$customer_id = $_SESSION['user_id'];

// Lấy danh sách tài xế liên quan đến đơn hàng khách
$drivers = $conn->query("
    SELECT DISTINCT u.id, u.username
    FROM USERS u
    JOIN DELIVERY d ON u.id = d.DriverID
    JOIN ORDERS o ON d.OrderID = o.OrderID
    WHERE o.CustomerID = $customer_id
");

// Xử lý gửi tin nhắn
if(isset($_POST['send_message'])){
    $receiver_id = intval($_POST['receiver_id']);
    $message = $conn->real_escape_string($_POST['message']);
    if(!empty($message)){
        $conn->query("INSERT INTO MESSAGES_DRIVER (SENDER_ID, RECEIVER_ID, MESSAGE) 
                      VALUES ($customer_id, $receiver_id, '$message')");
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<style>
body{font-family:sans-serif;padding:10px;background:#f0f2f5;}
.chat-container{display:flex;gap:20px;}
.driver-list{width:200px;background:#fff;padding:10px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
.driver-list div{padding:8px;cursor:pointer;border-radius:6px;margin-bottom:5px;}
.driver-list div.active, .driver-list div:hover{background:#4f46e5;color:white;}
.chat-box{flex:1;background:#fff;padding:10px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
.messages{height:300px;overflow-y:auto;border:1px solid #ccc;padding:10px;margin-bottom:10px;border-radius:6px;}
.message{margin-bottom:8px;}
.message.customer{color:#fff;background:#4f46e5;padding:6px 10px;border-radius:6px;display:inline-block;}
.message.driver{color:#000;background:#e2e8f0;padding:6px 10px;border-radius:6px;display:inline-block;}
form{display:flex;gap:6px;}
form input{flex:1;padding:8px;border-radius:6px;border:1px solid #ccc;}
form button{padding:8px 12px;background:#4f46e5;color:white;border:none;border-radius:6px;cursor:pointer;}
</style>
<script>
function selectDriver(id,name){
    document.getElementById('receiver_id').value = id;
    document.getElementById('chat-header').innerText = "Chat với "+name;
    document.querySelectorAll('.driver-list div').forEach(d=>d.classList.remove('active'));
    document.getElementById('driver_'+id).classList.add('active');
    fetchMessages();
}

function fetchMessages(){
    let receiver_id = document.getElementById('receiver_id').value;
    if(receiver_id=="") return;
    fetch('fetch_messages_customer.php?receiver_id='+receiver_id)
        .then(res=>res.text())
        .then(data=>{
            document.getElementById('chat-messages').innerHTML = data;
            document.getElementById('chat-messages').scrollTop = document.getElementById('chat-messages').scrollHeight;
        });
}
setInterval(fetchMessages,2000);
</script>
</head>
<body>

<div class="chat-container">
    <div class="driver-list">
        <h3>Tài xế</h3>
        <?php while($d=$drivers->fetch_assoc()): ?>
            <div id="driver_<?php echo $d['id']; ?>" onclick="selectDriver('<?php echo $d['id']; ?>','<?php echo $d['username']; ?>')">
                <?php echo htmlspecialchars($d['username']); ?>
            </div>
        <?php endwhile; ?>
    </div>

    <div class="chat-box">
        <h3 id="chat-header">Chọn tài xế để chat</h3>
        <div class="messages" id="chat-messages"></div>
        <form method="post" onsubmit="return !!document.getElementById('receiver_id').value;">
            <input type="hidden" name="receiver_id" id="receiver_id">
            <input type="text" name="message" placeholder="Nhập tin nhắn...">
            <button type="submit" name="send_message">Gửi</button>
        </form>
    </div>
</div>
</body>
</html>
