<?php
// load_messages_customer.php
include "config.php";
$customer_id = (int)$_GET["customer_id"];

$stmt = $conn->prepare("
    SELECT m.*, u.role as sender_role 
    FROM messages m 
    LEFT JOIN users u ON m.sender_id = u.id 
    WHERE (m.sender_id = ? AND m.receiver_id IN (SELECT id FROM users WHERE role='staff'))
       OR (m.receiver_id = ? AND m.sender_id IN (SELECT id FROM users WHERE role='staff'))
    ORDER BY m.timestamp ASC
");
$stmt->bind_param("ii", $customer_id, $customer_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $msg = htmlspecialchars($row['message']);
    $time = date("H:i", strtotime($row['timestamp']));

    if ($row['sender_id'] == $customer_id) {
        // Tin của khách
        echo "<div class='message msg-customer'>$msg<div class='time'>$time</div></div>";
    } else {
        // Tin của nhân viên
        echo "<div class='message msg-staff'>$msg<div class='time'>$time</div></div>";
    }
}
?>