<?php
include "config.php";
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "staff") {
    header("Location: login.php"); exit();
}

$message = "";

// Xử lý form khi submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_id     = (int)$_POST["customer_id"];
    $shipping_address = trim($_POST["shipping_address"]);
    $total_amount    = (float)str_replace([','], '', $_POST["total_amount"]);
    $order_status    = $_POST["order_status"];

    // Kiểm tra khách hàng tồn tại
    $check = $conn->prepare("SELECT CustomerID FROM CUSTOMER WHERE CustomerID = ?");
    $check->bind_param("i", $customer_id);
    $check->execute();
    if ($check->get_result()->num_rows == 0) {
        $message = "<div class='alert error'>Khách hàng không tồn tại!</div>";
    }
    // Kiểm tra dữ liệu
    elseif (empty($shipping_address) || $total_amount <= 0) {
        $message = "<div class='alert error'>Vui lòng điền đầy đủ và chính xác!</div>";
    }
    else {
        $stmt = $conn->prepare("INSERT INTO ORDERS (CustomerID, OrderDate, ShippingAddress, TotalAmount, OrderStatus) VALUES (?, CURDATE(), ?, ?, ?)");
        $stmt->bind_param("isds", $customer_id, $shipping_address, $total_amount, $order_status);
        if ($stmt->execute()) {
            $message = "<div class='alert success'>Thêm đơn hàng thành công! Mã đơn: <strong>#DH" . $conn->insert_id . "</strong></div>";
        } else {
            $message = "<div class='alert error'>Lỗi: " . $stmt->error . "</div>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Thêm Đơn Hàng Mới</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    :root { --p:#4f46e5; --pl:#6366f1; --bg:#f8fafc; --c:#fff; --t:#1e293b; --tl:#64748b; --ok:#10b981; --err:#ef4444; --b:#e2e8f0; }
    * { margin:0; padding:0; box-sizing:border-box; }
    body-aid { font-family:'Inter',sans-serif; background:var(--bg); color:var(--t); padding:30px; }
    .container { max-width:800px; margin:0 auto; background:var(--c); border-radius:20px; box-shadow:0 15px 40px rgba(0,0,0,0.1); overflow:hidden; }
    .header { background:var(--p); color:white; padding:25px 30px; text-align:center; font-size:24px; font-weight:700; }
    .body { padding:40px 50px; }
    .form-group { margin-bottom:25px; }
    label { display:block; font-weight:600; margin-bottom:8px; color:var(--t); }
    input, select, textarea {
        width:100%; padding:14px 16px; border:1px solid var(--b); border-radius:12px; font-size:16px; outline:none; transition:0.3s;
    }
    input:focus, select:focus, textarea:focus { border-color:var(--p); box-shadow:0 0 0 3px rgba(79,70,229,0.15); }
    .btn {
        background:var(--p); color:white; padding:14px 32px; border:none; border-radius:12px; font-size:16px; font-weight:600; cursor:pointer; transition:0.3s;
    }
    .btn:hover { background:#4338ca; }
    .btn-back { background:#6b7280; margin-left:10px; }
    .alert { padding:16px 20px; border-radius:12px; margin-bottom:25px; font-weight:500; }
    .alert.success { background:#ecfdf5; color:#059669; border:1px solid #86efac; }
    .alert.error { background:#fef2f2; color:#dc2626; border:1px solid #fca5a5; }
    .search-customer {
        position:relative;
    }
    #customer-suggestions {
        position:absolute; top:100%; left:0; right:0; background:white; border:1px solid var(--b); border-radius:12px; max-height:200px; overflow-y:auto; z-index:10; display:none;
    }
    .suggestion-item {
        padding:12px 16px; cursor:pointer; border-bottom:1px solid #eee;
    }
    .suggestion-item:hover { background:#f0f9ff; }
    .suggestion-item:last-child { border-bottom:none; }
</style>
</head>
<body>

<div class="container">
    <div class="header">
        Thêm Đơn Hàng Mới
    </div>

    <div class="body">
        <?php if($message) echo $message; ?>

        <form method="post" onsubmit="return validateForm()">
            <div class="form-group">
                <label>Tìm Khách Hàng (Họ tên hoặc ID)</label>
                <div class="search-customer">
                    <input type="text" id="customer_search" placeholder="Nhập tên hoặc ID khách..." autocomplete="off">
                    <div id="customer-suggestions"></div>
                </div>
                <input type="hidden" name="customer_id" id="customer_id" required>
                <small style="color:var(--tl);">Nhập tên khách → chọn từ gợi ý</small>
            </div>

            <div class="form-group">
                <label>Địa Chỉ Giao Hàng</label>
                <textarea name="shipping_address" rows="3" placeholder="Ví dụ: 123 Đường Láng, Đống Đa, Hà Nội" required></textarea>
            </div>

            <div class="form-group">
                <label>Tổng Tiền (VNĐ)</label>
                <input type="text" name="total_amount" placeholder="1.250.000" required oninput="formatNumber(this)">
            </div>

            <div class="form-group">
                <label>Trạng Thái Đơn Hàng</label>
                <select name="order_status">
                    <option value="Chờ xác nhận">Chờ xác nhận</option>
                    <option value="Đã xác nhận">Đã xác nhận</option>
                    <option value="Đang giao">Đang giao</option>
                    <option value="Đã giao">Đã giao</option>
                    <option value="Hủy đơn">Hủy đơn</option>
                </select>
            </div>

            <div style="text-align:center; margin-top:30px;">
                <button type="submit" class="btn">Thêm Đơn Hàng</button>
                <a href="giaodien.php" class="btn btn-back">Quay Lại</a>
            </div>
        </form>
    </div>
</div>

<script>
// Tìm kiếm khách hàng realtime
document.getElementById("customer_search").addEventListener("input", function() {
    const query = this.value.trim();
    const suggestions = document.getElementById("customer-suggestions");
    if (query.length < 2) {
        suggestions.style.display = "none";
        return;
    }

    fetch(`search_customer.php?q=${encodeURIComponent(query)}`)
    .then(r => r.json())
    .then(data => {
        suggestions.innerHTML = "";
        if (data.length === 0) {
            suggestions.innerHTML = "<div class='suggestion-item'>Không tìm thấy</div>";
        } else {
            data.forEach(c => {
                const div = document.createElement("div");
                div.className = "suggestion-item";
                div.textContent = `${c.FullName} (ID: ${c.CustomerID}) - ${c.PhoneNumber || 'Không có SĐT'}`;
                div.onclick = () => {
                    document.getElementById("customer_search").value = c.FullName;
                    document.getElementById("customer_id").value = c.CustomerID;
                    suggestions.style.display = "none";
                };
                suggestions.appendChild(div);
            });
        }
        suggestions.style.display = "block";
    });
});

// Định dạng số tiền
function formatNumber(input) {
    let v = input.value.replace(/\D/g, "");
    v = v.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    input.value = v;
}

function validateForm() {
    if (!document.getElementById("customer_id").value) {
        alert("Vui lòng chọn khách hàng từ gợi ý!");
        return false;
    }
    return true;
}
</script>
</body>
</html>