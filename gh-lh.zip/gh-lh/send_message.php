<?php
include "config.php";

// Lấy dữ liệu POST
$sender_id = isset($_POST["sender_id"]) ? (int)$_POST["sender_id"] : 0;
$role      = $_POST["role"] ?? "";
$message   = trim($_POST["message"] ?? "");

if ($sender_id <= 0 || $message === "") {
    exit("Thông tin gửi tin nhắn không hợp lệ");
}

// Xác định receiver
if ($role === "customer") {
    // Nếu là khách, gửi đến nhân viên đầu tiên
    $staff = $conn->query("SELECT id FROM users WHERE role='staff' LIMIT 1")->fetch_assoc();
    $receiver_id = $staff ? (int)$staff['id'] : 0;
} else {
    // Nếu là staff, cần gửi đến khách hàng
    $receiver_id = isset($_POST["receiver_id"]) ? (int)$_POST["receiver_id"] : 0;
}

if ($receiver_id <= 0) {
    exit("Người nhận không hợp lệ");
}

// Chèn tin nhắn vào bảng messages
$stmt = $conn->prepare("
    INSERT INTO messages (sender_id, receiver_id, message, timestamp)
    VALUES (?, ?, ?, NOW())
");
$stmt->bind_param("iis", $sender_id, $receiver_id, $message);
$stmt->execute();

echo "success";
?>
