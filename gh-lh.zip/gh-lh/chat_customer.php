<?php
include "config.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "customer") {
    header("Location: login.php");
    exit();
}

$customer_id   = $_SESSION["user_id"];
$customer_name = $_SESSION["name"] ?? "Khách hàng";
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chat với Nhân Viên Hỗ Trợ</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
    :root{
        --pri:#4361ee;
        --sec:#3f37c9;
        --light:#f8f9fa;
        --gray:#6c757d;
        --success:#06d6a0;
        --bg:#f0f2f5;
    }
    *{margin:0;padding:0;box-sizing:border-box}
    body{
        font-family:'Segoe UI',sans-serif;
        background:var(--bg);
        height:100vh;
        display:flex;
        flex-direction:column;
        color:#333;
    }
    .header{
        background:white;
        padding:15px 20px;
        box-shadow:0 2px 10px rgba(0,0,0,0.1);
        display:flex;
        align-items:center;
        gap:15px;
        z-index:10;
    }
    .avatar{
        width:50px;height:50px;
        background:var(--pri);
        color:white;
        border-radius:50%;
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:22px;
        font-weight:bold;
    }
    .info h3{margin:0;font-size:18px}
    .info small{color:var(--gray)}
    .status{
        width:12px;height:12px;
        background:var(--success);
        border-radius:50%;
        position:relative;
        top:-8px;
        left:35px;
        border:3px solid white;
    }
    .chat-body{
        flex:1;
        overflow-y:auto;
        padding:20px 20px 10px;
        display:flex;
        flex-direction:column;
        gap:12px;
    }
    .message{
        padding:11px 16px;
        border-radius:18px;
        max-width:75%;
        word-wrap:break-word;
        position:relative;
        animation:fadeIn 0.3s;
    }
    @keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
    .msg-customer{
        background:var(--pri);
        color:white;
        align-self:flex-end;
        border-bottom-right-radius:4px;
    }
    .msg-staff{
        background:white;
        border:1px solid #e0e0e0;
        align-self:flex-start;
        border-bottom-left-radius:4px;
    }
    .time{
        font-size:11px;
        margin-top:6px;
        opacity:0.8;
        text-align:right;
    }
    .msg-customer .time{color:#eee}
    .input-area{
        background:white;
        padding:15px 20px;
        box-shadow:0 -2px 10px rgba(0,0,0,0.05);
        display:flex;
        gap:12px;
        align-items:center;
    }
    input[type=text]{
        flex:1;
        padding:14px 18px;
        border-radius:30px;
        border:1px solid #ddd;
        outline:none;
        font-size:15px;
    }
    input:focus{border-color:var(--pri)}
    button{
        background:var(--pri);
        color:white;
        border:none;
        width:50px;height:50px;
        border-radius:50%;
        cursor:pointer;
        font-size:20px;
        transition:0.2s;
    }
    button:hover{background:var(--sec)}
    .welcome{
        text-align:center;
        color:#777;
        margin:40px 20px 0;
        font-size:15px;
        line-height:1.5;
    }
    .typing{
        font-style:italic;
        color:#999;
        align-self:flex-start;
        background:#fff;
        padding:10px 16px;
        border-radius:18px;
        border-bottom-left-radius:4px;
    }
</style>
</head>
<body>

<div class="header">
    <div class="avatar">NV</div>
    <div class="info">
        <h3>Nhân Viên Hỗ Trợ</h3>
        <small>Đang trực tuyến</small>
    </div>
    <div class="status"></div>
</div>

<div class="chat-body" id="messages">
    <div class="welcome">
        Chào bạn! Chúng tôi có thể giúp gì cho bạn hôm nay?<br>
        <small>Hãy gửi tin nhắn để bắt đầu cuộc trò chuyện</small>
    </div>
</div>

<div class="input-area">
    <input type="text" id="msg" placeholder="Nhập tin nhắn..." autocomplete="off"
           onkeypress="if(event.key==='Enter') sendMessage()">
    <button onclick="sendMessage()"><i class="fas fa-paper-plane"></i></button>
</div>

<script>
const customerId = <?= $customer_id ?>;

// Load tin nhắn
function loadMessages() {
    fetch("load_messages_customer.php?customer_id=" + customerId + "&t=" + Date.now())
    .then(r => r.text())
    .then(html => {
        const box = document.getElementById("messages");
        const wasAtBottom = box.scrollHeight - box.clientHeight - box.scrollTop < 100;

        // Xóa thông báo chào nếu đã có tin nhắn
        if(html.trim() !== "" && box.querySelector('.welcome')) {
            box.innerHTML = html;
        } else if(html.trim() !== "") {
            box.innerHTML = html;
        }

        if(wasAtBottom) box.scrollTop = box.scrollHeight;
    });
}
setInterval(loadMessages, 1200);
loadMessages();

// Gửi tin nhắn
function sendMessage() {
    const input = document.getElementById("msg");
    const msg = input.value.trim();
    if(!msg) return;

    fetch("send_message.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: `sender_id=${customerId}&role=customer&message=${encodeURIComponent(msg)}`
    }).then(() => {
        input.value = "";
        loadMessages();
    });
}
</script>

</body>
</html>