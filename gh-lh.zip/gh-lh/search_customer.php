<?php
include "config.php";
header('Content-Type: application/json');

$q = trim($_GET["q"] ?? "");
if (strlen($q) < 2) {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("SELECT CustomerID, FullName, PhoneNumber FROM CUSTOMER WHERE FullName LIKE ? OR CustomerID LIKE ? LIMIT 10");
$search = "%$q%";
$stmt->bind_param("ss", $search, $search);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode($data);
?>