<?php
include "config.php";

// Lấy CustomerID từ URL
if (!isset($_GET['customer_id']) || !is_numeric($_GET['customer_id'])) {
    die("Customer ID không hợp lệ");
}
$customer_id = (int)$_GET['customer_id'];

// Lấy tất cả tin nhắn giữa khách và staff
$stmt = $conn->prepare("
    SELECT m.*, u.role AS sender_role, u.username
    FROM messages m
    LEFT JOIN users u ON m.sender_id = u.id
    WHERE (m.sender_id = ? AND m.receiver_id IN (SELECT id FROM users WHERE role='staff'))
       OR (m.receiver_id = ? AND m.sender_id IN (SELECT id FROM users WHERE role='staff'))
    ORDER BY m.timestamp ASC
");
$stmt->bind_param("ii", $customer_id, $customer_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $msg = htmlspecialchars($row['message']);
    $time = date("H:i d/m", strtotime($row['timestamp']));

    // Phân biệt khách hay nhân viên
    if ($row['sender_role'] === 'customer' || $row['sender_id'] == $customer_id) {
        echo "<div class='message msg-customer'>$msg<div class='time'>$time</div></div>";
    } else {
        echo "<div class='message msg-staff'>$msg<div class='time'>$time</div></div>";
    }
}
?>
