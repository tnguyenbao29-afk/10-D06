<?php
session_start();
include "config.php";

// Kiểm tra role
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "driver") {
    header("Location: login.php");
    exit();
}

$driver_id = $_SESSION["user_id"];
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Tài xế';

// Xử lý nhận đơn
if(isset($_POST['nhan_don'])){
    $order_id = intval($_POST['order_id']);
    $conn->query("UPDATE DELIVERY SET DriverID=$driver_id, DeliveryStatus='Đang giao' 
                  WHERE OrderID=$order_id");
    header("Location: taixe.php");
    exit();
}

// Xử lý cập nhật trạng thái
if(isset($_POST['cap_nhat_trangthai'])){
    $delivery_id = intval($_POST['delivery_id']);
    $status = $conn->real_escape_string($_POST['status']);
    $conn->query("UPDATE DELIVERY SET DeliveryStatus='$status' WHERE DeliveryID=$delivery_id");
    header("Location: taixe.php");
    exit();
}

// Thống kê
$total_orders = $conn->query("SELECT COUNT(*) FROM DELIVERY WHERE DriverID=$driver_id")->fetch_row()[0];
$today = date('Y-m-d');
$orders_today = $conn->query("SELECT COUNT(*) FROM DELIVERY WHERE DriverID=$driver_id AND DeliveryDate='$today'")->fetch_row()[0];

// Lấy danh sách đơn hàng assigned hoặc chưa nhận
$deliveries = $conn->query("
    SELECT d.DeliveryID, o.OrderID, o.OrderDate, c.FullName, o.ShippingAddress, o.TotalAmount, 
           IFNULL(d.DeliveryStatus, 'Chờ nhận') AS DeliveryStatus,
           IFNULL(d.DriverID, 0) AS DriverID
    FROM DELIVERY d
    JOIN ORDERS o ON d.OrderID = o.OrderID
    JOIN CUSTOMER c ON o.CustomerID = c.CustomerID
    WHERE d.DriverID IS NULL OR d.DriverID = $driver_id
    ORDER BY CASE 
                 WHEN d.DeliveryStatus='Đang giao' THEN 1
                 WHEN d.DeliveryStatus='Đã giao' THEN 2
                 ELSE 0
             END ASC, o.OrderDate DESC
");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Dashboard Tài Xế</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root {
    --primary: #4f46e5; --primary-light: #6366f1; --sidebar: #1e1b4b; --bg: #f8fafc; --card: #ffffff;
    --text: #1e293b; --text-light: #64748b; --success: #10b981; --warning: #f59e0b; --border: #e2e8f0;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; display:flex; height:100vh; background:var(--bg); overflow:hidden; }

/* Sidebar */
.sidebar { width:240px; background:linear-gradient(135deg, var(--sidebar), #312e81); color:white; padding:30px 0; box-shadow:6px 0 20px rgba(0,0,0,0.15); }
.logo { text-align:center; padding:0 20px 40px; border-bottom:1px solid rgba(255,255,255,0.1); }
.logo i { font-size:48px; color:#c4b5fd; }
.logo h2 { margin-top:12px; font-size:22px; font-weight:700; }
.menu-item { padding:16px 28px; cursor:pointer; display:flex; align-items:center; gap:16px; font-weight:500; transition:all 0.3s; }
.menu-item:hover { background:rgba(255,255,255,0.12); padding-left:35px; }
.menu-item.active { background:var(--primary-light); position:relative; }
.menu-item.active::before { content:''; position:absolute; left:0; top:0; bottom:0; width:5px; background:white; }

/* Main Content */
.main-content { flex:1; padding:30px; overflow-y:auto; }
.header-title { font-size:28px; font-weight:700; color:var(--primary); margin-bottom:8px; display:flex; align-items:center; gap:12px; }
.subtitle { color:var(--text-light); font-size:15px; margin-bottom:30px; }

/* Stats */
.stats-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(200px,1fr)); gap:24px; margin-bottom:40px; }
.stat-card { background:var(--card); border-radius:20px; padding:24px; box-shadow:0 10px 30px rgba(0,0,0,0.08); transition:0.3s; }
.stat-card:hover { transform:translateY(-8px); }
.stat-card .icon { width:60px; height:60px; border-radius:16px; display:flex; align-items:center; justify-content:center; font-size:28px; color:white; margin-bottom:16px; }
.stat-card h3 { font-size:14px; color:var(--text-light); margin-bottom:8px; }
.stat-card .value { font-size:32px; font-weight:700; color:var(--text); }

/* Table */
table { width:100%; border-collapse:collapse; margin-top:20px; }
th, td { padding:12px; border:1px solid #ccc; text-align:left; }
th { background:#4f46e5; color:white; }
.status { padding:5px 12px; border-radius:20px; color:white; font-weight:600; }
.status.pending { background:#f59e0b; }
.status.ongoing { background:#10b981; }
.status.completed { background:#6b7280; }
button { padding:6px 12px; border:none; border-radius:6px; cursor:pointer; margin-right:6px; }
button.nhan { background:#4f46e5; color:white; }
button.update { background:#10b981; color:white; }
form { display:inline; }

/* Chat */
.chat-frame { width:100%; height:400px; border:none; border-radius:10px; box-shadow:0 5px 20px rgba(0,0,0,0.12); margin-top:30px; }
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="logo">
        <i class="fas fa-truck"></i>
        <h2>Tài Xế</h2>
    </div>
    <div class="menu-item active" onclick="show('trangchu', this)"><i class="fas fa-home"></i><span>Trang Chủ</span></div>
    <div class="menu-item" onclick="window.location='logout.php';"><i class="fas fa-sign-out-alt"></i><span>Đăng Xuất</span></div>
</div>

<!-- Main Content -->
<div class="main-content">
    <!-- Trang Chủ -->
    <div id="trangchu" class="content active">
        <div class="header-title">Trang Chủ</div>
        <p class="subtitle">Chào mừng <strong><?php echo htmlspecialchars($username); ?></strong></p>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="icon" style="background:#4f46e5;"><i class="fas fa-shopping-cart"></i></div>
                <h3>Tổng Đơn Hàng</h3>
                <div class="value"><?php echo $total_orders; ?></div>
            </div>
            <div class="stat-card">
                <div class="icon" style="background:#10b981;"><i class="fas fa-calendar-day"></i></div>
                <h3>Đơn Hôm Nay</h3>
                <div class="value"><?php echo $orders_today; ?></div>
            </div>
        </div>
    </div>

    <!-- Đơn Hàng -->
    <div id="donhang" class="content">
        <div class="header-title">Đơn Hàng</div>
        <p class="subtitle">Danh sách đơn hàng bạn quản lý</p>
        <table>
            <thead>
                <tr>
                    <th>Mã đơn</th><th>Khách hàng</th><th>Địa chỉ</th><th>Tổng tiền</th><th>Trạng thái</th><th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $deliveries->fetch_assoc()): ?>
                <tr>
                    <td>#DH<?php echo $row['OrderID']; ?></td>
                    <td><?php echo $row['FullName']; ?></td>
                    <td><?php echo $row['ShippingAddress']; ?></td>
                    <td><?php echo number_format($row['TotalAmount']); ?> đ</td>
                    <td>
                        <?php 
                        $cls = 'pending';
if($row['DeliveryStatus']=='In Progress') $cls='ongoing';
if($row['DeliveryStatus']=='Delivered') $cls='completed';

                        echo "<span class='status $cls'>{$row['DeliveryStatus']}</span>";
                        ?>
                    </td>
                    <td>
                        <?php if($row['DeliveryStatus']=='Chờ nhận'): ?>
                        <form method="post">
                            <input type="hidden" name="order_id" value="<?php echo $row['OrderID']; ?>">
                            <button type="submit" name="nhan_don" class="nhan">Nhận đơn</button>
                        </form>
                        <?php endif; ?>
                        
                        <?php if($row['DeliveryStatus']=='Đang giao'): ?>
                        <form method="post">
                            <input type="hidden" name="delivery_id" value="<?php echo $row['DeliveryID']; ?>">
                            <select name="status">
    <option value="In Progress" <?php if($row['DeliveryStatus']=='In Progress') echo 'selected'; ?>>In Progress</option>
    <option value="Delivered" <?php if($row['DeliveryStatus']=='Delivered') echo 'selected'; ?>>Delivered</option>
</select>

                            <button type="submit" name="cap_nhat_trangthai" class="update">Cập nhật</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Liên hệ khách -->
    <div id="lienhe" class="content">
        <div class="header-title">Liên Hệ Khách Hàng</div>
        <p class="subtitle">Gửi yêu cầu hoặc hỏi thông tin đơn hàng</p>
        <iframe src="chat_taixe.php" class="chat-frame"></iframe>
    </div>
</div>

<script>
function show(id, el){
    document.querySelectorAll('.content').forEach(c => c.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
    el.classList.add('active');
}
</script>
</body>
</html>
