<?php
include "config.php"; // config.php đã session_start() và kết nối DB

// Kiểm tra đăng nhập khách hàng
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "customer") {
    header("Location: login.php");
    exit();
}

// Xử lý submit form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerID = $_SESSION["user_id"];
    $shippingAddress = $conn->real_escape_string($_POST['shippingAddress']);
    $totalAmount = floatval($_POST['totalAmount']); // tổng tiền nhập tay hoặc tính ra
    $orderDate = date('Y-m-d');
    $orderStatus = "Chờ xác nhận"; // trạng thái mặc định

    $sql = "INSERT INTO ORDERS (CustomerID, OrderDate, ShippingAddress, TotalAmount, OrderStatus)
            VALUES ($customerID, '$orderDate', '$shippingAddress', $totalAmount, '$orderStatus')";

    if ($conn->query($sql)) {
        header("Location: dashboard_customer.php");
        exit();
    } else {
        $error = "Lỗi: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Thêm Đơn Hàng</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
body { font-family:'Inter',sans-serif; background:#f0f2f5; padding:40px; }
.container { max-width:500px; margin:auto; background:white; padding:30px; border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,0.1); }
h2 { text-align:center; margin-bottom:20px; color:#4f46e5; }
form input, form textarea { width:100%; padding:12px 16px; margin-bottom:16px; border-radius:8px; border:1px solid #cbd5e1; font-size:14px; }
form button { width:100%; padding:12px; background:#4f46e5; color:white; font-size:16px; border:none; border-radius:12px; cursor:pointer; }
form button:hover { background:#4338ca; }
.error { color:red; margin-bottom:16px; text-align:center; }
a.back { display:block; text-align:center; margin-top:20px; text-decoration:none; color:#4f46e5; }
a.back:hover { text-decoration:underline; }
</style>
</head>
<body>
<div class="container">
    <h2>Thêm Đơn Hàng</h2>
    <?php if (!empty($error)) echo "<div class='error'>$error</div>"; ?>
    <form method="POST" action="">
        <label>Địa chỉ giao hàng</label>
        <textarea name="shippingAddress" required placeholder="Nhập địa chỉ giao hàng"></textarea>

        <label>Tổng tiền (VNĐ)</label>
        <input type="number" name="totalAmount" required min="0" placeholder="Nhập tổng tiền">

        <button type="submit">Thêm Đơn Hàng</button>
    </form>
    <a class="back" href="khachhang.php"><i class="fas fa-arrow-left"></i> Quay lại Dashboard</a>
</div>
</body>
</html>
