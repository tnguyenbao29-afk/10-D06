<?php
include "config.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

$sql = "
    SELECT u.id, u.username
    FROM users u
    JOIN messages m 
        ON (u.id = m.sender_id OR u.id = m.receiver_id)
    WHERE u.role = 'customer'
    GROUP BY u.id
    ORDER BY MAX(m.timestamp) DESC
";

$result = $conn->query($sql);

if(!$result){
    die('SQL ERROR: ' . $conn->error);
}

$customers = [];
while ($row = $result->fetch_assoc()) {
    $customers[] = [
        'id' => $row['id'],
        'name' => $row['username']
    ];
}

header('Content-Type: application/json');
echo json_encode($customers);
?>
