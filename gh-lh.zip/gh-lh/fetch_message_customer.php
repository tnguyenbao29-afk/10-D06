<?php
session_start();
include "config.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='customer') exit();

$customer_id = $_SESSION['user_id'];
$receiver_id = intval($_GET['receiver_id']);

$res = $conn->query("
    SELECT * FROM MESSAGES_DRIVER
    WHERE (SENDER_ID=$customer_id AND RECEIVER_ID=$receiver_id)
       OR (SENDER_ID=$receiver_id AND RECEIVER_ID=$customer_id)
    ORDER BY SENT_AT ASC
");

while($row = $res->fetch_assoc()){
    $cls = ($row['SENDER_ID']==$customer_id)?'customer':'driver';
    echo "<div class='message $cls'>".htmlspecialchars($row['MESSAGE'])."</div>";
}
?>
