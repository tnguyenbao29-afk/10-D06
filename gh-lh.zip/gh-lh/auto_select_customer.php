<?php
include "config.php";

$result = $conn->query("
    SELECT u.id, COALESCE(c.FullName, u.username, 'Khách hàng') AS name
    FROM users u
    LEFT JOIN customer c ON u.id = c.CustomerID
    WHERE u.role = 'customer'
    ORDER BY u.id ASC LIMIT 1
");

header('Content-Type: application/json');
if ($result && $row = $result->fetch_assoc()) {
    echo json_encode(['id' => (int)$row['id'], 'name' => $row['name']]);
} else {
    echo json_encode(['id' => 0, 'name' => 'Chưa có khách']);
}
?>