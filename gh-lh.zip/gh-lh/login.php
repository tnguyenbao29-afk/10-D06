<?php
include "config.php"; // config.php xử lý session_start an toàn

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && $password === $user["password"]) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["role"]    = $user["role"];
        $_SESSION["name"]    = $username;

        // Chuyển hướng theo role
        if($user["role"] == "customer") {
            header("Location: khachhang.php");
        } elseif($user["role"] == "staff") {
            header("Location: giaodien.php");
        } elseif($user["role"] == "driver") {
            header("Location: taixe.php");
        }
        exit();
    } else {
        $error = "Sai tên đăng nhập hoặc mật khẩu!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng nhập</title>
<style>
body{background: linear-gradient(135deg,#667eea,#764ba2);min-height:100vh;display:flex;align-items:center;justify-content:center;margin:0;font-family:Segoe UI}
form{background:#fff;padding:40px;border-radius:16px;width:360px;box-shadow:0 20px 40px rgba(0,0,0,.1);text-align:center}
input{width:100%;padding:14px;margin:10px 0;border-radius:8px;border:1px solid #ddd;font-size:16px}
button{width:100%;padding:14px;background:#667eea;color:#fff;border:none;border-radius:8px;font-size:16px;cursor:pointer}
button:hover{background:#5a67d8}
.error{color:#e74c3c;margin-top:10px}
</style>
</head>
<body>
<form method="post">
    <h2>Đăng nhập</h2>
    <input type="text" name="username" placeholder="Tên đăng nhập" required>
    <input type="password" name="password" placeholder="Mật khẩu" required>
    <button type="submit">Đăng nhập</button>
    <?php if(!empty($error)) echo "<p class='error'>$error</p>"; ?>
</form>
</body>
</html>
