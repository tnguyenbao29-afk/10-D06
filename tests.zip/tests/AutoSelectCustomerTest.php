<?php
namespace Tests;

use PHPUnit\Framework\TestCase;

class AutoSelectCustomerTest extends TestCase
{
    private $conn;

    protected function setUp(): void
    {
        $this->conn = $this->createMock(\mysqli::class);
        $GLOBALS['conn'] = $this->conn;
    }

    public function testHasCustomer()
    {
        $result = $this->createMock(\mysqli_result::class);
        $result->method('fetch_assoc')->willReturn(['id' => 7, 'name' => 'Trần Thị B']);

        $this->conn->method('query')->willReturn($result);

        ob_start();
        include __DIR__ . '/../auto_select_customer.php';
        $json = ob_get_clean();

        $this->assertJsonStringEqualsJsonString('{"id":7,"name":"Tr\u1ea7n Th\u1ecb B"}', $json);
    }
}