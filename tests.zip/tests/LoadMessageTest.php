<?php


namespace Tests;

use PHPUnit\Framework\TestCase;

class LoadMessageTest extends TestCase
{
    private $conn;

    protected function setUp(): void
    {
        // Mock mysqli connection
        $this->conn = $this->createMock(\mysqli::class);
        $GLOBALS['conn'] = $this->conn;

        // Reset GET mỗi test
        $_GET = [];
    }

    /** Test 1: Có tin nhắn từ cả customer và staff */
    public function testLoadMessagesWithBothCustomerAndStaff()
    {
        $_GET['customer_id'] = '15';

        // Mock prepared statement
        $stmt = $this->createMock(\mysqli_stmt::class);
        $result = $this->createMock(\mysqli_result::class);

        // Giả lập 2 tin nhắn
        $result->method('fetch_assoc')
            ->willReturnOnConsecutiveCalls(
                [
                    'message' => 'Chào anh',
                    'timestamp' => '2025-04-05 10:30:00',
                    'sender_id' => 15,
                    'sender_role' => 'customer',
                    'username' => 'khach123'
                ],
                [
                    'message' => 'Dạ anh chờ em chút ạ',
                    'timestamp' => '2025-04-05 10:32:00',
                    'sender_id' => 3,
                    'sender_role' => 'staff',
                    'username' => 'nhanvien01'
                ],
                null // kết thúc vòng lặp
            );

        $stmt->method('get_result')->willReturn($result);

        // Mock execute thành công
        $stmt->expects($this->once())->method('execute')->willReturn(true);

        // Mock bind_param đúng kiểu "ii"
        $stmt->expects($this->once())
             ->method('bind_param')
             ->with('ii', 15, 15);

        // Mock prepare
        $this->conn->expects($this->once())
                   ->method('prepare')
                   ->willReturn($stmt);

        // Bắt output HTML
        ob_start();
        include __DIR__ . '/../load_message.php';
        $output = ob_get_clean();

        // Kiểm tra HTML đúng định dạng
        $this->assertStringContainsString('msg-customer', $output);
        $this->assertStringContainsString('msg-staff', $output);
        $this->assertStringContainsString('Chào anh', $output);
        $this->assertStringContainsString('Dạ anh chờ em chút ạ', $output);
        $this->assertStringContainsString('10:30 05/04', $output);
        $this->assertStringContainsString('10:32 05/04', $output);
    }

    /** Test 2: Không có tin nhắn nào → output rỗng */
    public function testNoMessagesReturnsEmpty()
    {
        $_GET['customer_id'] = '20';

        $stmt = $this->createMock(\mysqli_stmt::class);
        $result = $this->createMock(\mysqli_result::class);

        $result->method('fetch_assoc')->willReturn(null); 
        $stmt->method('get_result')->willReturn($result);
        $stmt->expects($this->once())->method('execute')->willReturn(true);

        $this->conn->method('prepare')->willReturn($stmt);

        ob_start();
        include __DIR__ . '/../load_message.php';
        $output = ob_get_clean();

        $this->assertEmpty(trim($output));
    }

    /** Test 3: Customer ID không hợp lệ → die() */
    public function testInvalidCustomerIdDies()
    {
        $_GET['customer_id'] = 'abc'; 

        $this->expectException(\Exception::class);
        $this->expectExceptionMessage('die() called');

        
        function die($msg) {
            throw new \Exception('die() called');
        }

        include __DIR__ . '/../load_message.php';
    }

   /** Test 4: Thiếu customer_id → die() */
    public function testMissingCustomerIdDies()
    {
        $_GET = []; 

        $this->expectException(\Exception::class);
        $this->expectExceptionMessage('die() called'); 
        include __DIR__ . '/../load_message.php';
    }