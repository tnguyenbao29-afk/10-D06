<?php
namespace Tests;

use PHPUnit\Framework\TestCase;

class SendMessageTest extends TestCase
{
    private $conn;

    protected function setUp(): void
    {
        $this->conn = $this->createMock(\mysqli::class);
        $GLOBALS['conn'] = $this->conn;
    }

    public function testSendMessageFromCustomer()
    {
        $_POST = [
            'sender_id' => '15',
            'role' => 'customer',
            'message' => 'Cho tôi hỏi đơn hàng'
        ];

        $result = $this->createMock(\mysqli_result::class);
        $result->method('fetch_assoc')->willReturn(['id' => 2]); // staff id

        $stmt = $this->createMock(\mysqli_stmt::class);
        $stmt->method('execute')->willReturn(true);

        $this->conn->method('query')->willReturn($result);
        $this->conn->method('prepare')->willReturn($stmt);

        ob_start();
        include __DIR__ . '/../send_message.php';
        $output = ob_get_clean();

        $this->assertEquals('success', trim($output));
    }
}
