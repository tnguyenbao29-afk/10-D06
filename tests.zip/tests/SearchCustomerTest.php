<?php
namespace Tests;

use PHPUnit\Framework\TestCase;

class SearchCustomerTest extends TestCase
{
    private $conn;

    protected function setUp(): void
    {
        $this->conn = $this->createMock(\mysqli::class);
        $GLOBALS['conn'] = $this->conn;
    }

    public function testSearchFound()
    {
        $_GET['q'] = 'nguyen';

        $stmt = $this->createMock(\mysqli_stmt::class);
        $result = $this->createMock(\mysqli_result::class);

        $result->method('fetch_assoc')
            ->willReturnOnConsecutiveCalls(
                ['CustomerID' => 1, 'FullName' => 'Nguyễn Văn A', 'PhoneNumber' => '0901'],
                null
            );

        $stmt->method('get_result')->willReturn($result);
        $this->conn->method('prepare')->willReturn($stmt);

        ob_start();
        include __DIR__ . '/../search_customer.php';
        $json = ob_get_clean();

        $expected = '[{"CustomerID":1,"FullName":"Nguy\u1ec5n V\u0103n A","PhoneNumber":"0901"}]';
        $this->assertJsonStringEqualsJsonString($expected, $json);
    }
}