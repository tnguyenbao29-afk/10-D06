<?php
require_once __DIR__ . '/../vendor/autoload.php';

// Mock các hàm toàn cục để tránh die() hoặc header() thực sự khi test
if (!function_exists('header')) {
    function header($string, $replace = true, $http_response_code = 0) {
        // Không làm gì cả
    }
}

if (!function_exists('exit')) {
    function exit($status = 0) {
        throw new \Exception('exit() called');
    }
}

if (!function_exists('die')) {
    function die($message = '') {
        throw new \Exception('die() called');
    }
}

// Xóa session trước mỗi test
$_SESSION = [];
$_POST = [];
$_GET = [];
$_SERVER['REQUEST_METHOD'] = 'GET';