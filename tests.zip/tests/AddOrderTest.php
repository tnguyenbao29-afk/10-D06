<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

class AddOrderTest extends TestCase
{
    private $conn;

    protected function setUp(): void
    {
        $this->conn = $this->createMock(\mysqli::class);
        $GLOBALS['conn'] = $this->conn;

        // Reset globals
        $_SESSION = [];
        $_POST = [];
        $_SERVER['REQUEST_METHOD'] = 'GET';
    }

    /** Test 1: Redirect nếu không phải staff */
    public function testRedirectIfNotStaff()
    {
        $_SESSION = ['user_id' => 1, 'role' => 'customer']; // Sai role

        $headers = [];
        function header($str) {
            global $headers;
            $headers[] = $str;
        }
        function exit() {
            throw new \Exception('Redirected');
        }

        try {
            include __DIR__ . '/../add_order.php';
        } catch (\Exception $e) {
            $this->assertContains('Location: login.php', $headers);
        }
    }

    /** Test 2: Thêm order thành công */
    public function testAddOrderSuccess()
    {
        $_SESSION = ['user_id' => 1, 'role' => 'staff'];
        $_POST = [
            'customer_id' => '10',
            'shipping_address' => '123 Hà Nội',
            'total_amount' => '1,250,000',
            'order_status' => 'Đang xử lý'
        ];
        $_SERVER['REQUEST_METHOD'] = 'POST';

        // Mock check customer
        $checkStmt = $this->createMock(\mysqli_stmt::class);
        $checkResult = $this->createMock(\mysqli_result::class);
        $checkResult->method('num_rows')->willReturn(1);
        $checkStmt->method('get_result')->willReturn($checkResult);
        $checkStmt->expects($this->once())->method('execute')->willReturn(true);

        // Mock insert
        $insertStmt = $this->createMock(\mysqli_stmt::class);
        $insertStmt->expects($this->once())->method('bind_param')->with('isds', 10, '123 Hà Nội', 1250000.0, 'Đang xử lý');
        $insertStmt->expects($this->once())->method('execute')->willReturn(true);
        $insertStmt->expects($this->once())->method('close');

        $this->conn->insert_id = 999;

        $this->conn->expects($this->exactly(2))
                   ->method('prepare')
                   ->willReturnOnConsecutiveCalls($checkStmt, $insertStmt);

        include __DIR__ . '/../add_order.php';

        $this->assertStringContainsString('Thêm đơn hàng thành công! Mã đơn: <strong>#DH999</strong>', $message);
    }

    /** Test 3: Customer không tồn tại */
    public function testCustomerNotExist()
    {
        $_SESSION = ['user_id' => 1, 'role' => 'staff'];
        $_POST = [
            'customer_id' => '999',
            'shipping_address' => 'abc',
            'total_amount' => '100000',
            'order_status' => 'Pending'
        ];
        $_SERVER['REQUEST_METHOD'] = 'POST';

        $checkStmt = $this->createMock(\mysqli_stmt::class);
        $checkResult = $this->createMock(\mysqli_result::class);
        $checkResult->method('num_rows')->willReturn(0);
        $checkStmt->method('get_result')->willReturn($checkResult);
        $checkStmt->expects($this->once())->method('execute')->willReturn(true);

        $this->conn->expects($this->once())
                   ->method('prepare')
                   ->willReturn($checkStmt);

        include __DIR__ . '/../add_order.php';

        $this->assertStringContainsString('Khách hàng không tồn tại!', $message);
    }

    /** Test 4: Input invalid (empty address hoặc total <=0) */
    public function testInvalidInput()
    {
        $_SESSION = ['user_id' => 1, 'role' => 'staff'];
        $_POST = [
            'customer_id' => '10',
            'shipping_address' => '',
            'total_amount' => '0',
            'order_status' => 'Pending'
        ];
        $_SERVER['REQUEST_METHOD'] = 'POST';

        $checkStmt = $this->createMock(\mysqli_stmt::class);
        $checkResult = $this->createMock(\mysqli_result::class);
        $checkResult->method('num_rows')->willReturn(1);
        $checkStmt->method('get_result')->willReturn($checkResult);
        $checkStmt->expects($this->once())->method('execute')->willReturn(true);

        $this->conn->expects($this->once())
                   ->method('prepare')
                   ->willReturn($checkStmt);

        include __DIR__ . '/../add_order.php';

        $this->assertStringContainsString('Vui lòng điền đầy đủ và chính xác!', $message);
    }

    /** Test 5: Insert thất bại */
    public function testInsertFailure()
    {
        $_SESSION = ['user_id' => 1, 'role' => 'staff'];
        $_POST = [
            'customer_id' => '10',
            'shipping_address' => '123 Hà Nội',
            'total_amount' => '100000',
            'order_status' => 'Pending'
        ];
        $_SERVER['REQUEST_METHOD'] = 'POST';

        $checkStmt = $this->createMock(\mysqli_stmt::class);
        $checkResult = $this->createMock(\mysqli_result::class);
        $checkResult->method('num_rows')->willReturn(1);
        $checkStmt->method('get_result')->willReturn($checkResult